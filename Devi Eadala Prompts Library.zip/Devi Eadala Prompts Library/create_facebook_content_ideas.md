I run a property maintenance/handyman business and I am not sure what to post on my new Facebook page or where to get relevant content. Can you help me with the following:

- Suggest different types of content I can post on my Facebook page to engage my audience.
- Provide ideas for specific posts that highlight my services.
- Recommend sources and methods for finding or creating content for my Facebook page. 
- Offer tips on how to maintain consistency and engage with followers regularly.
- Advise on any tools or resources that might be useful for managing and scheduling posts.

Ask me clarifying questions until you are 95% confident you can complete the task successfully. Take a deep breath and take it step by step. Remember to search the internet to retrieve up-to-date information.