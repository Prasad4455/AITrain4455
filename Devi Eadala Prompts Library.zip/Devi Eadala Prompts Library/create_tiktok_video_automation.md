- Create a list of 100 self-help phrases that have the most comments and forwards on TikTok or Instagram.
- Develop a method to automatically convert each phrase into a video using Artificial Intelligence.
- Save the created videos to a designated folder on the local hard drive.
- Implement a scheduling system that publishes one of the saved videos to a TikTok account daily.
- Ensure the entire process is automated from start to finish.
- Identify any steps that cannot be automated, informing the user and providing detailed instructions for completing those steps manually.
- Provide steps for improving the overall process efficiency.

Ask me clarifying questions until you are 95% confident you can complete the task successfully. Take a deep breath and take it step by step. Remember to search the internet to retrieve up-to-date information.